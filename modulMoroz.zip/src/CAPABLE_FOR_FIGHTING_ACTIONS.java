public interface CAPABLE_FOR_FIGHTING_ACTIONS {

    void fight();
    void report();
}
